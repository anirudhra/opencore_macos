//
//  AppDelegate.swift
//  AMDFramebufferUtility
//
//  Created by jogle on 15/6/29.
//  Copyright (c) 2015年 joglelew. All rights reserved.
//

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {



    func applicationDidFinishLaunching(aNotification: NSNotification) {
        // Insert code here to initialize your application
    }

    func applicationWillTerminate(aNotification: NSNotification) {
        // Insert code here to tear down your application
    }


}

